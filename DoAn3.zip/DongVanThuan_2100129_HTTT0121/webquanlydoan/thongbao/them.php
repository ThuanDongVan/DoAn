<?php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $giangVien = $_POST['giangVien'];
    $tieuDe = $_POST['tieuDe'];
    $noiDung = $_POST['noiDung'];
    $ngayTao = $_POST['ngayTao'];

    $mysqli = new mysqli('localhost', 'root', '', 'quanlydoan');
    if ($mysqli->connect_error) {
        die('Kết nối thất bại: ' . $mysqli->connect_error);
    }
    if(empty($tieuDe) || empty($noiDung) || empty($ngayTao)){
        echo "Vui lòng điền đầy đủ thông tin";
    } else {
        try {
            $sql = "INSERT INTO thongbao (IDGiangVien_ThongBao, TieuDe, NoiDung, NgayTao) VALUE (?,?,?,?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->execute([$giangVien, $tieuDe, $noiDung, $ngayTao]);

            header("Location: thongbao.php");
         
            exit;
        } catch(PDOException $e){
            echo "Lỗi: " . $e->getMessage();
        }
    }
    $stmt->close();
    $mysqli->close();
}
?>