<?php 
// Kết nối cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "quanlydoan";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'delete') {
    $ids = explode(',', $_POST['ids']); // Tách các ID
    $placeholders = implode(',', array_fill(0, count($ids), '?')); // Placeholder cho prepare statement
    $stmt = $conn->prepare("DELETE FROM thongbao WHERE IDThongBao IN ($placeholders)");
    $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
    if ($stmt->execute()) {
        echo "Xóa thành công.";
    } else {
        echo "Lỗi khi xóa: " . $stmt->error;
    }
    exit;
}

?>