<?php
$pdo = new PDO("mysql:host=localhost;dbname=quanlydoan", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $idthongBao = $_GET['id'];

    // Lấy thông tin đề tài
    $stmt = $pdo->prepare("SELECT * FROM thongbao WHERE IDThongBao = ?");
    $stmt->execute([$idthongBao]);
    $thongbao = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$thongbao) {
        die("Thông báo không tồn tại!");
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['idThongBao']) && !empty($_POST['idThongBao'])) {
        $idthongBao = $_POST['idThongBao'];
        $giangVien = $_POST['giangVien'];
        $tieuDe = $_POST['tieuDe'];
        $noiDung = $_POST['noiDung'];
        $ngayTao = $_POST['ngayTao'];

        $sql = "UPDATE thongbao 
                SET IDGiangVien_ThongBao = ?, TieuDe = ?, NoiDung = ?, NgayTao = ?
                WHERE IDThongBao = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$giangVien, $tieuDe, $noiDung, $ngayTao, $idthongBao]);

        // Uncomment the header to redirect after updating
        header("Location: thongbao.php");
        exit;
    } else {
        die("Lỗi: idThongBao không được xác định.");
    }
}