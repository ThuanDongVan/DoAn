<?php
session_start();

// Giả sử quyền người dùng được lưu trong session
$isAdmin = isset($_SESSION['VaiTro']) && $_SESSION['VaiTro'] === 'admin';
echo json_encode(['isAdmin' => $isAdmin]);
?>
