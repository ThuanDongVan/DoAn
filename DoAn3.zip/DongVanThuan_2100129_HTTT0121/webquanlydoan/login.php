<?php
session_start(); // Khởi động session

$conn = new mysqli('localhost', 'root', '', 'quanlydoan');
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    

    // Sử dụng prepared statement để kiểm tra email và password
    $stmt = $conn->prepare("SELECT VaiTro, IDSinhVien FROM users WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($VaiTro, $idSinhVien);
        $stmt->fetch();

        // Lưu thông tin vào session
        $_SESSION['email'] = $email;
        $_SESSION['VaiTro'] = $VaiTro;
        $_SESSION['IDSinhVien'] = $idSinhVien; // Lưu ID sinh viên từ cơ sở dữ liệu

        
        // Kiểm tra session
        echo "Session VaiTro: " . $_SESSION['VaiTro'];
        
        // Chuyển hướng tới trang chính
        header("Location: detai/detai.php");
        exit();
    } else {
        // Thông báo lỗi
        echo "<script>alert('Sai email hoặc mật khẩu'); window.location.href='login.html';</script>";
    }

    $stmt->close();
}
$conn->close();
?>
