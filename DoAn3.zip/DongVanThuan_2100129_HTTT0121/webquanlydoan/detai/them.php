<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nhận dữ liệu từ form
    $tenDeTai = $_POST['TenDeTai'];
    $moTa = $_POST['MoTa'];
    $ngayBatDau = $_POST['NgayBatDau'];
    $ngayKetThuc = $_POST['NgayKetThuc'];
    $nghanh = $_POST['TenNganh'];
    $giangVien = $_POST['HoTen'];
    $loaiDoAn = $_POST['TenLoaiDoAn'];


    $mysqli = new mysqli('localhost', 'root', '', 'quanlydoan');
    if ($mysqli->connect_error) {
        die('Kết nối thất bại: ' . $mysqli->connect_error);
    }

    for($i = 0; $i < count($tenDeTai); $i++){
        // Kiểm tra các trường dữ liệu
        if (empty($tenDeTai) || empty($moTa) || empty($ngayBatDau) || empty($ngayKetThuc) || empty($nghanh) || empty($giangVien) || empty($loaiDoAn)) {
            echo "Vui lòng điền đầy đủ thông tin!";
            exit;
        }

        $stmt = $mysqli->prepare("INSERT INTO detai (IDGiangVien_DeTai, IDNganh_DeTai, IDLoaiDoAn_DeTai, TenDeTai, MoTa, NgayBatDau, NgayKetThuc) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $giangVien[$i], $nghanh[$i], $loaiDoAn[$i], $tenDeTai[$i], $moTa[$i], $ngayBatDau[$i], $ngayKetThuc[$i]);

        if (!$stmt->execute()) {
            echo "Lỗi: " . $stmt->error;
            exit;
        }
    }
    $stmt->close();
    $mysqli->close();

    header('Location: detai.php');
}
?>
