<?php

// Kết nối tới cơ sở dữ liệu
$conn = new mysqli('localhost', 'root', '', 'quanlydoan');
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Lấy dữ liệu JSON từ client
$requestBody = file_get_contents('php://input');
$data = json_decode($requestBody, true); // Giải mã JSON thành mảng PHP
file_put_contents('log.txt', "Method: " . $_SERVER['REQUEST_METHOD'] . "\n", FILE_APPEND);
file_put_contents('log.txt', "Decoded data: " . print_r($data, true) . "\n", FILE_APPEND);
file_put_contents('log.txt', "Request URI: " . $_SERVER['REQUEST_URI'] . "\n", FILE_APPEND);
file_put_contents('log.txt', "User Agent: " . $_SERVER['HTTP_USER_AGENT'] . "\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    echo json_encode(['status' => 'error', 'message' => 'Trang này chỉ chấp nhận yêu cầu POST']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Kiểm tra dữ liệu nhận được từ client
    if (is_null($data)) {
        echo json_encode(['status' => 'error', 'message' => 'Dữ liệu JSON không hợp lệ']);
        exit;
    }

    // Lấy các giá trị từ mảng $data
    $tenDeTai = $data['TenDeTai'] ?? null;
    $moTa = $data['MoTa'] ?? null;
    $ngayBatDau = $data['NgayBatDau'] ?? null;
    $ngayKetThuc = $data['NgayKetThuc'] ?? null;
    $nghanh = $data['TenNganh'] ?? null;
    $giangVien = $data['HoTen'] ?? null;
    $loaiDoAn = $data['TenLoaiDoAn'] ?? null;
    $trangThai = $data['TrangThai'] ?? null;
    $ngayChon = $data['NgayChon'] ?? null;

    // Kiểm tra các trường bắt buộc
    if (!$tenDeTai || !$moTa || !$ngayBatDau || !$ngayKetThuc || !$nghanh || !$giangVien || !$loaiDoAn || !$trangThai || !$ngayChon) {
        echo json_encode(['status' => 'error', 'message' => 'Một số trường bắt buộc bị thiếu']);
        exit;
    }

    // Chèn dữ liệu vào cơ sở dữ liệu
    $sql = "INSERT INTO sinhvien_chondetai (IDGiangVien_DTDC, IDNganh_DTDC, IDLoaiDoAn_DTDC, TenDeTai, MoTa, NgayBatDau, NgayKetThuc, TrangThai, NgayChon) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssss", $giangVien, $nghanh, $loaiDoAn, $tenDeTai, $moTa, $ngayBatDau, $ngayKetThuc, $trangThai, $ngayChon);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Lưu thành công']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Lỗi SQL: ' . $stmt->error]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Yêu cầu không hợp lệ']);
}

$conn->close();
?>
