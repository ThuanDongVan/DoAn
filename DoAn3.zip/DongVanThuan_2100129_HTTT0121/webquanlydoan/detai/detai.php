<?php
session_start();
// Include các file cần thiết để kết nối cơ sở dữ liệu (tùy thuộc vào cách bạn cài đặt)
$servername = "localhost"; // Hoặc IP của máy chủ cơ sở dữ liệu
$username = "root";        // Tên người dùng cơ sở dữ liệu
$password = "";            // Mật khẩu cơ sở dữ liệu
$dbname = "quanlydoan";    // Tên cơ sở dữ liệu bạn muốn kết nối

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Hàm tìm kiếm hoặc lấy toàn bộ dữ liệu
function getDeTai($keyword = '')
{
    global $conn;
    $keyword = $conn->real_escape_string($keyword);
    $sql = "SELECT 
        *
    FROM 
        detai
    JOIN 
        nganh ON detai.IDNganh_DeTai = nganh.IDNganh
    JOIN 
        giangvien ON detai.IDGiangVien_DeTai = giangvien.IDGiangVien
    JOIN 
        loaidoan ON detai.IDLoaiDoAn_DeTai = loaidoan.IDLoaiDoAn
    ";

    if (!empty($keyword)) {
        $sql .= " WHERE detai.TenDeTai LIKE '%$keyword%' 
                   OR giangvien.HoTen LIKE '%$keyword%' 
                   ";
    }

    $result = $conn->query($sql);

    $data = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}

// Xử lý các yêu cầu POST
$keyword = '';
$deTaiList = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        // Chuyển hướng đến trang thêm đề tài
        header("Location: addDetai.php");
        exit();
    } elseif (isset($_POST['search'])) {
        $keyword = $_POST['keyword'] ?? '';
        $_SESSION['keyword'] = $keyword; // Lưu từ khóa vào session
        header("Location: " . $_SERVER['PHP_SELF']); // Chuyển hướng đến GET
        exit();
    }
} elseif (isset($_SESSION['keyword'])) {
    // Lấy từ khóa từ session sau khi chuyển hướng
    $keyword = $_SESSION['keyword'];
    unset($_SESSION['keyword']); // Xóa từ khóa khỏi session sau khi sử dụng
}

// Lấy danh sách đề tài
$deTaiList = getDeTai($keyword);


if (!isset($_SESSION['VaiTro'])) {
    echo "Vai trò không tồn tại trong session.";
    exit();
}
// echo "Vai trò hiện tại: " . $_SESSION['VaiTro'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đề tài</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    
    <style>
        .action-buttons {
            display: flex;
            /* Sử dụng flexbox để căn ngang */
            align-items: center;
            /* Căn giữa theo chiều dọc */
            gap: 10px;
            /* Tạo khoảng cách giữa các nút */
        }

        .action-buttons button {
            margin: 0;
            /* Loại bỏ margin mặc định */
            padding: 10px 20px;
            /* Đặt padding tùy ý */
            font-size: 16px;
            /* Đặt kích thước chữ */
        }

        tr.selected {
            background-color: #ffe5e5;
            /* Màu nền nổi bật */
            color: #d9534f;
            /* Màu chữ */
        }
        .form-wrapper {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .form-wrapper input[type="text"] {
            width: 50%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-wrapper button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>

<body id="body" data-role="<?php echo $_SESSION['VaiTro']; ?>">
    <div class="l-navbar navbar-collapsed" id="navbar">
        <div class="nav">
            <div>
                <a href="" class="nav__logo">
                    <img src="../logo-ctut-300x300.png" alt="" class="nav__logo-icon">
                    <span class="nav__logo-text"></span>
                </a>
                <ul class="nav__list" style="padding-right: 0px; padding-left: 0px;">
                    <a href="" class="nav__link active">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__text">Home</span>
                    </a>
                    <a href="detai.php" class="nav__link active">
                        <i class='bx bx-receipt nav__icon'></i>
                        <span class="nav__text">Đề Tài</span>
                    </a>
                    <a href="../tiendo/tiendo.php" class="nav__link active">
                        <i class='bx bx-time-five nav__icon'></i>
                        <span class="nav__text">Tiến Độ</span>
                    </a>
                    <a href="../thongbao/thongbao.php" class="nav__link active">
                        <i class='bx bx-bell nav__icon'></i>
                        <span class="nav__text">Thông Báo</span>
                    </a>
                    <a href="../danhgia/danhgia.php" class="nav__link active">
                        <i class='bx bx-check-circle nav__icon'></i>
                        <span class="nav__text">Đánh Giá</span>
                    </a>
                </ul>
            </div>
            <a href="../login.html" class="nav__link active">
                <i class='bx bx-log-out-circle nav__icon'></i>
                <span class="nav__text">Đăng Xuất</span>
            </a>
        </div>
    </div>
    <div class="banner content content-collapsed" style="padding-top: 0px;">
        <div class="bg">
            <header class="bg-blue-800 text-white py-2">
                <div class="container mx-auto flex justify-between items-center px-4">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-clock"></i>
                        <span id="dateDisplay"></span>
                    </div>
                    <div>
                        <a href="https://www.facebook.com/cnttdhktcnct" target="_blank" class="hover:text-blue-300">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </div>
                </div>
            </header>
        </div>
        <img alt="University banner" height="200" src="../cropped-banner_web.png" width="1300" />

        <div class="container-fluid">
            <h1 class="h3 mb-2 text-gray-800">Danh sách đồ án</h1>

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <!-- <h6 class="m-0 font-weight-bold text-primary">Danh sách đồ án</h6> -->
                    <div class="action-buttons">
                        <button id="add-btn" class="btn btn-success">Thêm</button>
                        <button id="delete-btn" class="btn btn-danger">Xóa</button>
                        <button id="edit-btn" class="btn btn-warning">Sửa</button>
                    </div>
                </div>
                <div class="card-body">
                    <div id="tbsinhvien" class="table-responsive">
                        <form method="POST" action="" class="form-wrapper">
                            <input type="text" id="keyword" name="keyword" class="" placeholder="Nhập tên giảng viên hoặc đề tài" value="<?php echo htmlspecialchars($keyword); ?>">
                            <button type="submit" name="search" class="btn btn-success">Tìm kiếm</button>
                        </form>
                        <h3 class="mt-5">Danh sách đề tài</h3>
                        <form id="actionForm" method="POST" action="">
                            <input type="hidden" name="action" id="actionInput" />
                            <input type="hidden" name="rowData" id="rowData" />
                        </form>

                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Tên đề tài</th>
                                    <th>Mô tả</th>
                                    <th>Ngày bắt đầu</th>
                                    <th>Ngày kết thúc</th>
                                    <th>Nghành</th>
                                    <th>Giảng viên hướng dẫn</th>
                                    <th>Loại đồ án</th>
                                    <th>Trạng thái</th>
                                    <th>Ngày chọn</th>
                                </tr>
                            </thead>
                            <!-- <tfoot>
                                    <tr>
                                        <th>Tên đề tài</th>
                                        <th>Mô tả</th>
                                        <th>Ngày bắt đầu</th>
                                        <th>Ngày kết thúc</th>
                                        <th>Nghành</th>
                                        <th>Giảng viên hướng dẫn</th>
                                        <th>Loại đồ án</th>
                                    </tr>
                                </tfoot> -->
                            <tbody id="tables-body">
                                <?php if (!empty($deTaiList)): ?>
                                    <?php foreach ($deTaiList as $row): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['TenDeTai']); ?></td>
                                            <td><?php echo htmlspecialchars($row['MoTa']); ?></td>
                                            <td><?php echo htmlspecialchars($row['NgayBatDau']); ?></td>
                                            <td><?php echo htmlspecialchars($row['NgayKetThuc']); ?></td>
                                            <td><?php echo htmlspecialchars($row['TenNganh']); ?></td>
                                            <td><?php echo htmlspecialchars($row['HoTen']); ?></td>
                                            <td><?php echo htmlspecialchars($row['TenLoaiDoAn']); ?></td>
                                            <td><?php echo htmlspecialchars($row['TrangThai']); ?></td>
                                            <td><?php echo htmlspecialchars($row['NgayChon']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3">Không có dữ liệu.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div id="tbgiangvien" class="table-responsive">
                        <form id="addForm" method="POST" action="them.php">
                            <table class="table table-bordered" id="dataTable">
                                <thead>
                                    <tr>
                                        <th>Tên đề tài</th>
                                        <th>Mô tả</th>
                                        <th>Ngày bắt đầu</th>
                                        <th>Ngày kết thúc</th>
                                        <th>Nghành</th>
                                        <th>Giảng viên hướng dẫn</th>
                                        <th>Loại đồ án</th>
                                    </tr>
                                </thead>
                                <tbody id="table-body">
                                    <!-- Dữ liệu sẽ được thêm động ở đây -->
                                </tbody>
                            </table>
                            <button class="btn btn-success">Lưu</button>
                        </form>
                        <form method="POST" action="" class="form-wrapper">
                            <input type="text" id="keyword" name="keyword" class="" placeholder="Nhập tên giảng viên hoặc đề tài" value="<?php echo htmlspecialchars($keyword); ?>">
                            <button type="submit" name="search" class="btn btn-success">Tìm kiếm</button>
                        </form>
                        <h3 class="mt-5">Danh sách đề tài</h3>
                        <form id="actionForm" method="POST" action="">
                            <input type="hidden" name="action" id="actionInput" />
                            <input type="hidden" name="rowData" id="rowData" />
                        </form>

                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Tên đề tài</th>
                                    <th>Mô tả</th>
                                    <th>Ngày bắt đầu</th>
                                    <th>Ngày kết thúc</th>
                                    <th>Nghành</th>
                                    <th>Giảng viên hướng dẫn</th>
                                    <th>Loại đồ án</th>
                                    <!-- <th>Trạng thái</th>
                                    <th>Ngày chọn</th> -->
                                </tr>
                            </thead>
                            <!-- <tfoot>
                                    <tr>
                                        <th>Tên đề tài</th>
                                        <th>Mô tả</th>
                                        <th>Ngày bắt đầu</th>
                                        <th>Ngày kết thúc</th>
                                        <th>Nghành</th>
                                        <th>Giảng viên hướng dẫn</th>
                                        <th>Loại đồ án</th>
                                    </tr>
                                </tfoot> -->
                            <tbody id="tables-body">
                                <?php if (!empty($deTaiList)): ?>
                                    <?php foreach ($deTaiList as $row): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['TenDeTai']); ?></td>
                                            <td><?php echo htmlspecialchars($row['MoTa']); ?></td>
                                            <td><?php echo htmlspecialchars($row['NgayBatDau']); ?></td>
                                            <td><?php echo htmlspecialchars($row['NgayKetThuc']); ?></td>
                                            <td><?php echo htmlspecialchars($row['TenNganh']); ?></td>
                                            <td><?php echo htmlspecialchars($row['HoTen']); ?></td>
                                            <td><?php echo htmlspecialchars($row['TenLoaiDoAn']); ?></td>
                                            <!-- <td><?php echo htmlspecialchars($row['TrangThai']); ?></td>
                                            <td><?php echo htmlspecialchars($row['NgayChon']); ?></td> -->
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3">Không có dữ liệu.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-----------------GiangVien------------------>
            <div id="dsdoancanduyet" class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Danh sách đồ án cần duyệt</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="selectedTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Tên đề tài</th>
                                    <th>Mô tả</th>
                                    <th>Ngày bắt đầu</th>
                                    <th>Ngày kết thúc</th>
                                    <th>Nghành</th>
                                    <th>Loại đồ án</th>
                                    <th>Giảng viên hướng dẫn</th>
                                    <th>Trạng thái</th>
                                    <th>Ngày chọn</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Các dữ liệu đã chọn sẽ được hiển thị ở đây -->

                            </tbody>
                        </table>
                        <button id="duyet-btn" class="btn btn-success">Duyệt</button>
                        <button id="tuchoi-btn" class="btn btn-danger">Từ chối</button>
                    </div>
                </div>
            </div>
            <!-----------------SinhVien------------------>
            <div id="dsdoandachon" class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Danh sách đồ án đã chọn</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <form action="chon_detai.php">
                            <table class="table table-bordered" id="selectedTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Tên đề tài</th>
                                        <th>Mô tả</th>
                                        <th>Ngày bắt đầu</th>
                                        <th>Ngày kết thúc</th>
                                        <th>Nghành</th>
                                        <th>Loại đồ án</th>
                                        <th>Giảng viên hướng dẫn</th>
                                        <th>Trạng thái</th>
                                        <th>Ngày chọn</th>
                                    </tr>
                                </thead>
                                <tbody id="selectedTableBody">
                                    <!-- Các dữ liệu đã chọn sẽ được hiển thị ở đây -->

                                </tbody>
                            </table>
                            <button id="select-btn" class="btn btn-success">Chọn</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <p>KHOA CÔNG NGHỆ THÔNG TIN</p>
            <p>Trường Đại học Kỹ thuật - Công nghệ Cần Thơ</p>
            <p>SĐT Khoa: 071.0389.7574</p>
            <p>FanPage: <a href="http://fb.com/cnttdhktcnct">fb.com/cnttdhktcnct/</a></p>
            <p>Email: <a href="mailto:gkhoacntt@cutet.edu.vn">khoacntt@ctuet.edu.vn/</a></p>
        </div>
    </div>
    <script>
        const addBtn = document.getElementById("add-btn");
        const tableBody = document.getElementById("table-body");

        // Khi nhấn nút "Thêm"
        addBtn.addEventListener("click", () => {
            const row = tableBody.insertRow();

            row.innerHTML = `
                <td><input type="text" name="TenDeTai[]" class="form-control" placeholder="Nhập tên đề tài" required></td>
                <td><input type="text" name="MoTa[]" class="form-control" placeholder="Nhập mô tả" required></td>
                <td><input type="date" name="NgayBatDau[]" class="form-control"required></td>
                <td><input type="date" name="NgayKetThuc[]" class="form-control"required></td>
                <td>
                    <select name="TenNganh[]" class="form-control" required>
                        <option value="">Chọn tên ngành</option>
                        <?php
                        $nganhList = $conn->query("SELECT IDNganh, TenNganh FROM nganh");
                        while ($row = $nganhList->fetch_assoc()) {
                            echo "<option value='{$row['IDNganh']}'>{$row['TenNganh']}</option>";
                        }
                        ?>
                    </select>
                </td>
                <td>
                    <select name="HoTen[]" class="form-control" required>
                        <option value="">Chọn giảng viên</option>
                        <?php
                        $giangvienList = $conn->query("SELECT IDGiangVien, HoTen FROM giangvien");
                        while ($row = $giangvienList->fetch_assoc()) {
                            echo "<option value='{$row['IDGiangVien']}'>{$row['HoTen']}</option>";
                        }
                        ?>
                    </select>
                </td>
                <td>
                    <select name="TenLoaiDoAn[]" class="form-control" required>
                        <option value="">Chọn loại đồ án</option>
                        <?php
                        $loaidoanList = $conn->query("SELECT IDLoaiDoAn, TenLoaiDoAn FROM loaidoan");
                        while ($row = $loaidoanList->fetch_assoc()) {
                            echo "<option value='{$row['IDLoaiDoAn']}'>{$row['TenLoaiDoAn']}</option>";
                        }
                        ?>
                    </select>
                </td>
                <td><button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">Xóa</button></td>
            `;
        });

        // Hàm xóa hàng
        function removeRow(button) {
            const row = button.closest('tr');
            row.remove();
        }
    </script>
    <script>
        const tableBodys = document.getElementById("tables-body");

        // Chức năng chọn dòng
        let selectedRows = [];

        tableBodys.addEventListener("click", (event) => {
            const row = event.target.closest("tr");
            if (row) {
                row.classList.toggle("selected"); // Bật/tắt trạng thái chọn
                const id = row.getAttribute("data-id");
                if (row.classList.contains("selected")) {
                    selectedRows.push(id); // Thêm ID dòng vào danh sách đã chọn
                } else {
                    selectedRows = selectedRows.filter((item) => item !== id); // Loại bỏ ID khỏi danh sách đã chọn
                }
            }
        });

        // Nút "Xóa"
        const deleteBtn = document.getElementById("delete-btn");
        deleteBtn.addEventListener("click", () => {
            if (selectedRows.length === 0) {
                alert("Vui lòng chọn ít nhất một dòng để xóa.");
                return;
            }

            if (confirm(`Bạn có chắc chắn muốn xóa ${selectedRows.length} đề tài đã chọn?`)) {
                // Gửi yêu cầu xóa đến server
                const formData = new FormData();
                formData.append("action", "delete");
                formData.append("ids", selectedRows.join(","));

                fetch("xoa.php", {
                        method: "POST",
                        body: formData,
                    })
                    .then((response) => response.text())
                    .then((data) => {
                        alert(data); // Hiển thị thông báo từ server
                        location.reload(); // Reload lại trang
                    })
                    .catch((error) => console.error("Lỗi:", error));
            }
        });

        // Nút "Sửa"
        const editBtn = document.getElementById("edit-btn");
        editBtn.addEventListener("click", () => {
            if (selectedRows.length !== 1) {
                alert("Vui lòng chọn một dòng duy nhất để sửa.");
                return;
            }

            // Chuyển hướng đến trang sửa với ID đã chọn
            const id = selectedRows[0];
            window.location.href = `formsuadetai.php?id=${id}`;
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const role = document.body.getAttribute("data-role");
            if (role === "GiangVien") {
                document.getElementById("add-btn").style.display = "block";
                document.getElementById("delete-btn").style.display = "block";
                document.getElementById("edit-btn").style.display = "block";
                document.getElementById("dsdoancanduyet").style.display = "block";
                document.getElementById("dsdoandachon").style.display = "none";
                document.getElementById("select-btn").style.display = "none";
                document.getElementById("tbsinhvien").style.display = "none";
                document.getElementById("tbgiangvien").style.display = "block";
            } else if (role === "SinhVien") {
                document.getElementById("dsdoancanduyet").style.display = "none";
                document.getElementById("dsdoandachon").style.display = "block";
                document.getElementById("addForm").style.display = "none";
                document.getElementById("edit-btn").style.display = "none";
                document.getElementById("add-btn").style.display = "none";
                document.getElementById("delete-btn").style.display = "none";
                document.getElementById("select-btn").style.display = "block";
                document.getElementById("tbsinhvien").style.display = "block";
                document.getElementById("tbgiangvien").style.display = "none";
            }
        });
    </script>
    <!-- <script>
        document.addEventListener("DOMContentLoaded", () => {
            // Lấy tất cả các dòng trong bảng danh sách đề tài
            const table = document.getElementById("tables-body");
            let selectedRow = null;

            // Xử lý khi nhấn vào dòng trong bảng
            table.addEventListener("click", (event) => {
                const tr = event.target.closest("tr");
                if (tr) {
                    // Bỏ chọn dòng trước đó
                    if (selectedRow) {
                        selectedRow.classList.remove("selected");
                    }

                    // Đánh dấu dòng được chọn
                    selectedRow = tr;
                    selectedRow.classList.add("selected");
                }
            });

            // Nút "Chọn"
            document.getElementById("select-btn").addEventListener("click", () => {
                if (!selectedRow) {
                    alert("Vui lòng chọn một đề tài!");
                    return;
                }

                // Lấy dữ liệu từ dòng được chọn
                const cells = selectedRow.querySelectorAll("td");
                const data = {
                    TenDeTai: cells[0]?.innerText.trim(), // Cột thứ 2: Tên đề tài
                    MoTa: cells[1]?.innerText.trim(), // Cột thứ 3: Mô tả
                    NgayBatDau: cells[2]?.innerText.trim(), // Cột thứ 4: Ngày bắt đầu
                    NgayKetThuc: cells[3]?.innerText.trim(), // Cột thứ 5: Ngày kết thúc
                    TenNganh: cells[4]?.innerText.trim(), // Cột thứ 6: Ngành
                    HoTen: cells[5]?.innerText.trim(), // Cột thứ 7: Giảng viên
                    TenLoaiDoAn: cells[6]?.innerText.trim(), // Cột thứ 8: Loại đồ án
                    TrangThai: cells[7]?.innerText.trim(), // Giá trị mặc định
                    NgayChon: new Date().toISOString().split('T')[0], // Ngày hiện tại
                };

                console.log("Dữ liệu gửi đi:", data);
                // Gửi dữ liệu tới server qua AJAX
                fetch("chon_detai.php", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify(data),
                    })
                    .then((response) => response.json())
                    .then((result) => {
                        if (result.status === "success") {
                            alert("Lưu thành công!");

                            // Thêm dữ liệu vào bảng danh sách đồ án đã chọn
                            addRowToSelectedTable(data);

                            // Xóa dòng khỏi bảng danh sách đề tài
                            selectedRow.remove();
                            selectedRow = null;
                        } else {
                            alert(result.message);
                        }
                    })
                    .catch((error) => {
                        console.error("Lỗi:", error);
                        alert("Đã xảy ra lỗi khi lưu dữ liệu.");
                    });
            });

            // Hàm thêm dòng vào bảng danh sách đồ án đã chọn
            function addRowToSelectedTable(data) {
                const selectedTableBody = document.getElementById("selectedTableBody");
                const newRow = selectedTableBody.insertRow();

                newRow.innerHTML = `
            <td>${data.TenDeTai}</td>
            <td>${data.MoTa}</td>
            <td>${data.NgayBatDau}</td>
            <td>${data.NgayKetThuc}</td>
            <td>${data.TenNganh}</td>
            <td>${data.HoTen}</td>
            <td>${data.TenLoaiDoAn}</td>
            <td>${data.TrangThai}</td>
            <td>${data.NgayChon}</td>
        `;
            }
        });
    </script> -->
    <script>
    document.addEventListener("DOMContentLoaded", () => {
        // Lấy tất cả các dòng trong bảng danh sách đề tài
        const table = document.getElementById("tables-body");
        const selectBtn = document.getElementById("select-btn");
        let selectedRow = null;

        if (!table) {
            console.error("Không tìm thấy bảng danh sách đề tài (tables-body).");
            return;
        }

        if (!selectBtn) {
            console.error("Không tìm thấy nút chọn (select-btn).");
            return;
        }

        // Xử lý khi nhấn vào dòng trong bảng
        table.addEventListener("click", (event) => {
            const tr = event.target.closest("tr");
            if (tr) {
                // Bỏ chọn dòng trước đó
                if (selectedRow) {
                    selectedRow.classList.remove("selected");
                }

                // Đánh dấu dòng được chọn
                selectedRow = tr;
                selectedRow.classList.add("selected");
            }
        });

        // Nút "Chọn"
        selectBtn.addEventListener("click", () => {
            if (!selectedRow) {
                alert("Vui lòng chọn một đề tài!");
                return;
            }

            // Lấy dữ liệu từ dòng được chọn
            const cells = selectedRow.querySelectorAll("td");
            if (cells.length < 8) {
                alert("Dữ liệu dòng được chọn không hợp lệ.");
                return;
            }

            const data = {
                TenDeTai: cells[0]?.innerText.trim() || "",
                MoTa: cells[1]?.innerText.trim() || "",
                NgayBatDau: cells[2]?.innerText.trim() || "",
                NgayKetThuc: cells[3]?.innerText.trim() || "",
                TenNganh: cells[4]?.innerText.trim() || "",
                HoTen: cells[5]?.innerText.trim() || "",
                TenLoaiDoAn: cells[6]?.innerText.trim() || "",
                TrangThai: cells[7]?.innerText.trim() || "Chưa xác định",
                NgayChon: new Date().toISOString().split("T")[0],
            };

            console.log("Dữ liệu gửi đi:", data);

            // Gửi dữ liệu tới server qua AJAX
            fetch("chon_detai.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })
                .then((response) => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then((result) => {
                    if (result.status === "success") {
                        alert("Lưu thành công!");

                        // Thêm dữ liệu vào bảng danh sách đồ án đã chọn
                        addRowToSelectedTable(data);

                        // Xóa dòng khỏi bảng danh sách đề tài
                        selectedRow.remove();
                        selectedRow = null;
                    } else {
                        alert(result.message);
                    }
                })
                .catch((error) => {
                    console.error("Lỗi:", error);
                    alert("Đã xảy ra lỗi khi lưu dữ liệu.");
                });
        });

        // Hàm thêm dòng vào bảng danh sách đồ án đã chọn
        function addRowToSelectedTable(data) {
            const selectedTableBody = document.getElementById("selectedTableBody");
            if (!selectedTableBody) {
                console.error("Không tìm thấy bảng danh sách đồ án đã chọn (selectedTableBody).");
                return;
            }

            const newRow = selectedTableBody.insertRow();

            newRow.innerHTML = `
                <td>${data.TenDeTai}</td>
                <td>${data.MoTa}</td>
                <td>${data.NgayBatDau}</td>
                <td>${data.NgayKetThuc}</td>
                <td>${data.TenNganh}</td>
                <td>${data.HoTen}</td>
                <td>${data.TenLoaiDoAn}</td>
                <td>${data.TrangThai}</td>
                <td>${data.NgayChon}</td>
            `;
        }
    });
</script>

    <script src="../js/date.js"></script>
    <script src="../js/main.js"></script>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../js/sb-admin-2.min.js"></script>
</body>

</html>