<?php
$pdo = new PDO("mysql:host=localhost;dbname=quanlydoan", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $idDeTai = $_GET['id'];

    // Lấy thông tin đề tài
    $stmt = $pdo->prepare("SELECT * FROM detai WHERE IDDeTai = ?");
    $stmt->execute([$idDeTai]);
    $detai = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$detai) {
        die("Đề tài không tồn tại!");
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idDeTai = $_POST['idDeTai'];
    $tenDeTai = $_POST['tenDeTai'];
    $moTa = $_POST['moTa'];
    $ngayBatDau = $_POST['ngayBatDau'];
    $ngayKetThuc = $_POST['ngayKetThuc'];
    $nghanh = $_POST['nghanh'];
    $giangVien = $_POST['giangVien'];
    $loaiDoAn = $_POST['loaiDoAn'];

    // Cập nhật dữ liệu
    $sql = "UPDATE detai 
            SET TenDeTai = ?, MoTa = ?, NgayBatDau = ?, NgayKetThuc = ?, IDNganh_DeTai = ?, IDGiangVien_DeTai = ?, IDLoaiDoAn_DeTai = ?
            WHERE IDDeTai = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$tenDeTai, $moTa, $ngayBatDau, $ngayKetThuc, $nghanh, $giangVien, $loaiDoAn, $idDeTai]);

    header("Location: detai.php");
    exit;
}
?>