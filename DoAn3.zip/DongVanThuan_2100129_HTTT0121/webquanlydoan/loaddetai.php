<?php
include 'config.php';

// Truy vấn để lấy dữ liệu
$sql = "SELECT 
    DeTai.IDDeTai, 
    DeTai.TenDeTai, 
    DeTai.MoTa, 
    DeTai.NgayBatDau, 
    DeTai.NgayKetThuc, 
    Nghanh.TenNghanh, 
    GiangVien.HoTen, 
    LoaiDoAn.TenLoaiDoAn
FROM 
    DeTai
JOIN 
    Nghanh ON DeTai.IDNganh_DeTai = Nghanh.IDNghanh
JOIN 
    GiangVien ON DeTai.IDGiangVien_DeTai = GiangVien.IDGiangVien
JOIN 
    LoaiDoAn ON DeTai.IDLoaiDoAn_DeTai = LoaiDoAn.IDLoaiDoAn;
";

$result = $conn->query($sql);

$data = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Trả dữ liệu dưới dạng JSON
echo json_encode($data);

$conn->close();
?>
