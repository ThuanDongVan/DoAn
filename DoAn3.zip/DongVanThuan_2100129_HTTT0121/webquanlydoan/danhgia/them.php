<!-- xuly-them-de-tai.php -->
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nhận dữ liệu từ form
    $tenDeTai = $_POST['tenDeTai'];
    $giangVien = $_POST['giangvien'];
    $noidung = $_POST['noidung'];
    $diemso = $_POST['diemso'];

    // Kiểm tra các trường dữ liệu
    if (empty($tenDeTai) || empty($giangVien) || empty($noidung) || empty($diemso)) {
        echo "Vui lòng điền đầy đủ thông tin!";
    } else {
        // Xử lý thêm vào cơ sở dữ liệu (giả sử có kết nối MySQL)
        // Ví dụ sử dụng PDO để kết nối và thực thi query

        try {
            $pdo = new mysqli("localhost", "root", "", "quanlydoan");
            // $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


            $sql = "INSERT INTO danhgiacuagiangvien (IDDeTai_DGGV, IDGiangVien_DGGV, NoiDungDanhGia, DiemSo)
                    VALUES (?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$tenDeTai, $giangVien, $noidung, $diemso]);

            header("Location: danhgia.php");
            exit;
        } catch (PDOException $e) {
            echo "Lỗi: " . $e->getMessage();
        }
    }
}
?>
