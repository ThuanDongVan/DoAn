<?php
session_start();
// Include các file cần thiết để kết nối cơ sở dữ liệu (tùy thuộc vào cách bạn cài đặt)
$servername = "localhost"; // Hoặc IP của máy chủ cơ sở dữ liệu
$username = "root";        // Tên người dùng cơ sở dữ liệu
$password = "";            // Mật khẩu cơ sở dữ liệu
$dbname = "quanlydoan";    // Tên cơ sở dữ liệu bạn muốn kết nối

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Hàm để lấy dữ liệu từ cơ sở dữ liệu
function getDanhGia()
{
    global $conn;
    $sql = "SELECT 
        *
    FROM 
        danhgiacuagiangvien
    JOIN 
        giangvien ON danhgiacuagiangvien.IDGiangVien_DGGV = giangvien.IDGiangVien
    JOIN 
        detai ON danhgiacuagiangvien.IDDeTai_DGGV = detai.IDDeTai; 
    ";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đánh giá</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/danhgia.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Custom fonts for this template -->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        tr.selected {
            background-color: #ffe5e5;
            /* Màu nền nổi bật */
            color: #d9534f;
            /* Màu chữ */
        }

        .action-buttons {
            display: flex;
            /* Sử dụng flexbox để căn ngang */
            align-items: center;
            /* Căn giữa theo chiều dọc */
            gap: 10px;
            /* Tạo khoảng cách giữa các nút */
        }

        .action-buttons button {
            margin: 0;
            /* Loại bỏ margin mặc định */
            padding: 10px 20px;
            /* Đặt padding tùy ý */
            font-size: 16px;
            /* Đặt kích thước chữ */
        }
    </style>
</head>

<body id="body" data-role="<?php echo $_SESSION['VaiTro']; ?>">
    <div class="l-navbar navbar-collapsed" id="navbar">
        <div class="nav">
            <div>
                <a href="" class="nav__logo">
                    <img src="../logo-ctut-300x300.png" alt="" class="nav__logo-icon">
                    <span class="nav__logo-text"></span>
                </a>
                <ul class="nav__list" style="padding-right: 0px; padding-left: 0px;">
                    <a href="" class="nav__link active">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__text">Home</span>
                    </a>
                    <a href="../detai/detai.php" class="nav__link active">
                        <i class='bx bx-receipt nav__icon'></i>
                        <span class="nav__text">Đề Tài</span>
                    </a>
                    <a href="../tiendo/tiendo.php" class="nav__link active">
                        <i class='bx bx-time-five nav__icon'></i>
                        <span class="nav__text">Tiến Độ</span>
                    </a>
                    <a href="../thongbao/thongbao.php" class="nav__link active">
                        <i class='bx bx-bell nav__icon'></i>
                        <span class="nav__text">Thông Báo</span>
                    </a>
                    <a href="danhgia.php" class="nav__link active">
                        <i class='bx bx-check-circle nav__icon'></i>
                        <span class="nav__text">Đánh Giá</span>
                    </a>
                </ul>
            </div>
            <a href="../login.html" class="nav__link active">
                <i class='bx bx-log-out-circle nav__icon'></i>
                <span class="nav__text">Đăng Xuất</span>
            </a>
        </div>
    </div>
    <div class="body_content content content-collapsed" style="padding-top: 0px;">
        <div class="bg">
            <header class="bg-blue-800 text-white py-2">
                <div class="container mx-auto flex justify-between items-center px-4">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-clock"></i>
                        <span id="dateDisplay"></span> <!-- Phần tử để hiển thị ngày -->
                    </div>
                    <div>
                        <a href="https://facebook.com" target="_blank" class="hover:text-blue-300">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </div>
                </div>
            </header>
        </div>
        <div>
            <img alt="University banner with text 'TRƯỜNG ĐẠI HỌC KỸ THUẬT - CÔNG NGHỆ CẦN THƠ KHOA CÔNG NGHỆ THÔNG TIN'"
                height="200" src="../cropped-banner_web.png" width="1300" />

            <div class="review-container">
                <header class="header">
                    <h1>Đánh Giá Đồ Án</h1>
                </header>
                <main class="content_danhgia">
                    <table class="review-table">
                        <thead>
                            <tr>
                                <th>Tên đề tài</th>
                                <th>Giảng viên</th>
                                <th>Nội dung</th>
                                <th>Điểm số</th>
                            </tr>
                        </thead>
                        <tbody id="tables-body">
                            <header class="header_notification">
                                <h1>Đánh giá</h1>
                                <div class="action-buttons">
                                    <button id="add-btn" onclick="location.href='formthem.php'" class="btn btn-success btn-add">Thêm đánh giá</button>
                                    <button class="btn btn-warning" id="edit-btn">Sửa</button>
                                    <button class="btn btn-danger" id="delete-btn">Xóa</button>
                                </div>

                            </header>
                            <?php
                            $danhgiagvs = getDanhGia();
                            if (!empty($danhgiagvs)) {
                                foreach ($danhgiagvs as $danhgiagv) {
                                    echo "<tr data-id = '{$danhgiagv['IDDanhGia']}'>
                                        <td>{$danhgiagv['TenDeTai']}</td>
                                        <td>{$danhgiagv['HoTen']}</td>
                                        <td>{$danhgiagv['NoiDungDanhGia']}</td>
                                        <td>{$danhgiagv['DiemSo']}</td>
                                    </tr>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </main>
            </div>
        </div>

        <div class="footer">
            <p>KHOA CÔNG NGHỆ THÔNG TIN</p>
            <p>Trường Đại học Kỹ thuật - Công nghệ Cần Thơ</p>
            <p>SĐT Khoa: 071.0389.7574</p>

            <p>FanPage: <a href="http://fb.com/cnttdhktcnct">fb.com/cnttdhktcnct/</a></p>
            <p>Email: <a href="mailto:gkhoacntt@cutet.edu.vn">khoacntt@ctuet.edu.vn/</a></p>
        </div>
    </div>
    <script>
        // Nút "Sửa"
        const editBtn = document.getElementById("edit-btn");
        editBtn.addEventListener("click", () => {
            if (selectedRows.length !== 1) {
                alert("Vui lòng chọn một dòng duy nhất để sửa.");
                return;
            }

            // Chuyển hướng đến trang sửa với ID đã chọn
            const id = selectedRows[0];
            window.location.href = `formsua.php?id=${id}`;
        });
    </script>
    <script>
        const tablesBody = document.getElementById("tables-body");
        // Chức năng chọn dòng
        let selectedRows = [];

        tablesBody.addEventListener("click", (event) => {
            const row = event.target.closest("tr");
            if (row) {
                row.classList.toggle("selected"); // Bật/tắt trạng thái chọn
                const id = row.getAttribute("data-id");
                if (row.classList.contains("selected")) {
                    selectedRows.push(id); // Thêm ID dòng vào danh sách đã chọn
                } else {
                    selectedRows = selectedRows.filter((item) => item !== id); // Loại bỏ ID khỏi danh sách đã chọn
                }
            }
        });


        // Nút "Xóa"
        const deleteBtn = document.getElementById("delete-btn");
        deleteBtn.addEventListener("click", () => {
            if (selectedRows.length === 0) {
                alert("Vui lòng chọn ít nhất một dòng để xóa.");
                return;
            }

            if (confirm(`Bạn có chắc chắn muốn xóa ${selectedRows.length} đề tài đã chọn?`)) {
                // Gửi yêu cầu xóa đến server
                const formData = new FormData();
                formData.append("action", "delete");
                formData.append("ids", selectedRows.join(","));

                fetch("xoa.php", {
                        method: "POST",
                        body: formData,
                    })
                    .then((response) => response.text())
                    .then((data) => {
                        alert(data); // Hiển thị thông báo từ server
                        location.reload(); // Reload lại trang
                    })
                    .catch((error) => console.error("Lỗi:", error));
            }
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const role = document.body.getAttribute("data-role");
            if (role === "GiangVien") {
                document.getElementById("add-btn").style.display = "block";
                document.getElementById("delete-btn").style.display = "block";
                document.getElementById("edit-btn").style.display = "block";
            } else if (role === "SinhVien") {
                //document.getElementById("addForm").style.display = "none";
                document.getElementById("edit-btn").style.display = "none";
                document.getElementById("add-btn").style.display = "none";
                document.getElementById("delete-btn").style.display = "none";
            }
        });
    </script>
    <script src="../js/date.js"></script>
    <script src="../js/main.js"></script>
</body>

</html>