<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "quanlydoan";

// Kết nối cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Kiểm tra yêu cầu từ AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {

    if (isset($_POST['ids']) && !empty($_POST['ids'])) {
        // Nhận danh sách ID từ client
        $ids = $_POST['ids']; 
        $idsArray = explode(",", $ids);

        // Xây dựng câu truy vấn SQL với placeholders
        $placeholders = implode(",", array_fill(0, count($idsArray), "?"));
        $sql = "DELETE FROM danhgiacuagiangvien WHERE IDDanhGia IN ($placeholders)";
        

        // Chuẩn bị câu lệnh
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind các tham số
            $stmt->bind_param(str_repeat("i", count($idsArray)), ...$idsArray);

            // Thực thi câu lệnh
            if ($stmt->execute()) {
                echo "Xóa thành công các đề tài đã chọn!";
            } else {
                echo "Lỗi khi xóa: " . $conn->error;
            }

            // Đóng câu lệnh
            $stmt->close();
        } else {
            echo "Lỗi khi chuẩn bị truy vấn: " . $conn->error;
        }
    } else {
        echo "Không có ID nào được gửi lên.";
    }
} else {
    echo "Yêu cầu không hợp lệ.";
}

// Đóng kết nối
$conn->close();
?>
