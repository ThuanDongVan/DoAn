
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa thông tin đánh giá</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/tiendo.css">
    <!-- Custom fonts for this template -->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
        /* Tiêu đề */
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            color: #333;
            font-weight: bold;
        }

        /* Bảng */
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
        }

        /* Dòng bảng và ô */
        table th,
        table td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            text-align: left;
        }

        table th {
            background-color: #2e90e4;
            color: white;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        /* Input text và textarea */
        input[type="text"],
        input[type="date"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            transition: border 0.3s, box-shadow 0.3s;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        textarea:focus,
        select:focus {
            border: 1px solid #4CAF50;
            box-shadow: 0 0 5px rgba(76, 175, 80, 0.5);
            outline: none;
        }

        /* Dropdown tùy chỉnh */
        select {
            appearance: none;
            /* Ẩn mũi tên mặc định */
            background-image: url('data:image/svg+xml;utf8,<svg fill="%234CAF50" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>');
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 16px;
            padding-right: 30px;
            /* Để chừa chỗ cho mũi tên */
            cursor: pointer;
        }

        /* Nút */
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        button:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(76, 175, 80, 0.5);
        }

        /* Nút quay lại */
        button.secondary {
            background-color: #777;
        }

        button.secondary:hover {
            background-color: #555;
        }

        /* Margin cho các nút */
        .button-group {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
    </style>
</head>

<body id="body">
    <div class="l-navbar navbar-collapsed" id="navbar">
    <div class="nav">
            <div>
                <a href="" class="nav__logo">
                    <img src="../logo-ctut-300x300.png" alt="" class="nav__logo-icon">
                    <span class="nav__logo-text"></span>
                </a>
                <ul class="nav__list" style="padding-right: 0px; padding-left: 0px;">
                    <a href="" class="nav__link active">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__text">Home</span>
                    </a>
                    <a href="../detai/detai.php" class="nav__link active">
                        <i class='bx bx-receipt nav__icon'></i>
                        <span class="nav__text">Đề Tài</span>
                    </a>
                    <a href="../tiendo/tiendo.php" class="nav__link active">
                        <i class='bx bx-time-five nav__icon'></i>
                        <span class="nav__text">Tiến Độ</span>
                    </a>
                    <a href="../thongbao/thongbao.php" class="nav__link active">
                        <i class='bx bx-bell nav__icon'></i>
                        <span class="nav__text">Thông Báo</span>
                    </a>
                    <a href="danhgia.php" class="nav__link active">
                        <i class='bx bx-check-circle nav__icon'></i>
                        <span class="nav__text">Đánh Giá</span>
                    </a>
                </ul>
            </div>
            <a href="../Login.html" class="nav__link active">
                <i class='bx bx-log-out-circle nav__icon'></i>
                <span class="nav__text">Đăng Xuất</span>
            </a>
        </div>
    </div>
    <div class="banner content content-collapsed" style="padding-top: 0px;">
        <div class="bg">
            <header class="bg-blue-800 text-white py-2">
                <div class="container mx-auto flex justify-between items-center px-4">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-clock"></i>
                        <span id="dateDisplay"></span> <!-- Phần tử để hiển thị ngày -->
                    </div>
                    <div>
                        <a href="https://facebook.com" target="_blank" class="hover:text-blue-300">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </div>
                </div>
            </header>
        </div>
        <img alt="University banner with text 'TRƯz`ỜNG ĐẠI HỌC KỸ THUẬT - CÔNG NGHỆ CẦN THƠ KHOA CÔNG NGHỆ THÔNG TIN'"
            height="200" src="../cropped-banner_web.png" width="1300" />
        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <h2 class="text-center">Cập Nhật Thông Tin Đánh Giá</h2>
            <form method="POST" action="them.php">
                
                <!-- Table Chứa Form -->
                <table class="table table-hover table-bordered shadow">
                    <tr>
                        <th>Tên đề tài</th>
                        <td>
                            <select id="tenDeTai" name="tenDeTai" class="form-select" required>
                                <option value="" disabled selected>Chọn Tên Đề Tài</option>
                                <?php
                                $pdo = new PDO("mysql:host=localhost;dbname=quanlydoan", "root", "");
                                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                                $query = $pdo->query("SELECT IDDeTai, TenDeTai FROM detai");
                                while ($row = $query->fetch(PDO::FETCH_ASSOC)) {                                
                                    echo "<option value='{$row['IDDeTai']}'>{$row['TenDeTai']}</option>";
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Giảng Viên</th>
                        <td>
                            <select name="giangvien" class="form-select" required>
                                <option value="" disabled selected>Chọn Giảng Viên</option>
                                <?php
                                $query = $pdo->query("SELECT IDGiangVien, HoTen FROM giangvien");
                                while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
                                    echo "<option value='{$row['IDGiangVien']}' $selected>{$row['HoTen']}</option>";
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Nội Dung</th>
                        <td>
                            <input type="text" name="noidung" class="form-control" required>
                        </td>
                    </tr>
                    <tr>
                        <th>Điểm Số</th>
                        <td>
                            <input type="text" name="diemso" class="form-control"required>
                        </td>
                    </tr>

                </table>

                <!-- Nút Submit -->
                <div class="text-center">
                    <button type="submit" class="btn btn-success px-4">Cập Nhật</button>
                    <a href="danhgia.php" class="btn btn-secondary px-4">Quay Lại</a>
                </div>
            </form>
        </div>
        <div class="footer">
            <p>KHOA CÔNG NGHỆ THÔNG TIN</p>
            <p>Trường Đại học Kỹ thuật - Công nghệ Cần Thơ</p>
            <p>SĐT Khoa: 071.0389.7574</p>

            <p>FanPage: <a href="http://fb.com/cnttdhktcnct">fb.com/cnttdhktcnct/</a></p>
            <p>Email: <a href="mailto:gkhoacntt@cutet.edu.vn">khoacntt@ctuet.edu.vn/</a></p>
        </div>
    </div>
    <script>
        // Hàm sửa hàng
        function editRow(button) {
            const row = button.closest('tr');
            const cells = row.querySelectorAll('td');

            // Nếu đang ở trạng thái chỉnh sửa, thì lưu dữ liệu
            if (button.innerText === 'Sửa') {
                cells.forEach((cell, index) => {
                    // Bỏ qua cột cuối (nút hành động)
                    if (index < cells.length - 1) {
                        const inputValue = cell.innerText;
                        cell.innerHTML = `<input type="text" value="${inputValue}" class="form-control">`;
                    }
                });
                button.innerText = 'Lưu';
            } else {
                // Lưu dữ liệu sau khi sửa
                cells.forEach((cell, index) => {
                    if (index < cells.length - 1) {
                        const input = cell.querySelector('input');
                        if (input) {
                            cell.innerText = input.value; // Cập nhật lại nội dung của ô
                        }
                    }
                });
                button.innerText = 'Sửa';
            }
        }
    </script>
    <script src="../js/main.js"></script>
    <script src="../js/date.js"></script>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>