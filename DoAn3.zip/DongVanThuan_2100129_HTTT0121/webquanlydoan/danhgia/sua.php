<?php
$pdo = new PDO("mysql:host=localhost;dbname=quanlydoan", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $idDanhGia = $_GET['id'];

    // Lấy thông tin đề tài
    $stmt = $pdo->prepare("SELECT * FROM danhgiacuagiangvien WHERE IDDanhGia = ?");
    $stmt->execute([$idThongBao]);
    $danhgia= $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$danhgia) {
        die("Đánh giá không tồn tại!");
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $IDDanhGia = $_POST['IDDanhGia'];
    $tenDeTai = $_POST['tenDeTai'];
    $giangVien = $_POST['giangVien'];
    $noiDung = $_POST['noiDung'];
    $diemSo = $_POST['diemSo'];

    // Cập nhật dữ liệu
    $sql = "UPDATE danhgiacuagiangvien 
            SET IDDeTai_DGGV = ?, IDGiangVien_DGGV = ?, NoiDungDanhGia = ?, DiemSo = ?
            WHERE IDDanhGia = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$tenDeTai, $giangVien, $noiDung, $diemSo, $IDDanhGia]);

    header("Location: danhgia.php");
    exit;
}
?>