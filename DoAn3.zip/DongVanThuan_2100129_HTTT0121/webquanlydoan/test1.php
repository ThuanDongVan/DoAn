<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đề tài</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        .action-buttons button {
            margin-right: 8px;
            margin-bottom: 8px;
        }

        .action-buttons button:last-child {
            margin-right: 0;
        }

        tr.selected {
            background-color: #ffe5e5;
            /* Màu nền nổi bật */
            color: #d9534f;
            /* Màu chữ */
        }
    </style>
</head>
<form id="addForm" method="POST" action="formthemdetai.php">
    <table class="table table-bordered" id="dataTable">
        <thead>
            <tr>
                <th><label for="tenDeTai">Tên Đề Tài:</label>
                    <input type="text" name="tenDeTai" value="<?= htmlspecialchars($detai['TenDeTai']) ?>" required><br>
                </th>
                <th><label for="moTa">Mô Tả:</label>
                    <textarea name="moTa" required><?= htmlspecialchars($detai['MoTa']) ?></textarea><br>
                </th>
                <th>Ngày bắt đầu</th>
                <th>Ngày kết thúc</th>
                <th>Nghành</th>
                <th>Giảng viên hướng dẫn</th>
                <th>Loại đồ án</th>
            </tr>
        </thead>
        <tbody id="table-body">
            <!-- Dữ liệu sẽ được thêm động ở đây -->
        </tbody>
    </table>
    <button type="submit" class="btn btn-success">Lưu</button>
</form>
<form action="sua.php" method="POST">
    <input type="hidden" name="idDeTai" value="<?= htmlspecialchars($detai['IDDeTai']) ?>">

    <label for="tenDeTai">Tên Đề Tài:</label>
    <input type="text" name="tenDeTai" value="<?= htmlspecialchars($detai['TenDeTai']) ?>" required><br>

    <label for="moTa">Mô Tả:</label>
    <textarea name="moTa" required><?= htmlspecialchars($detai['MoTa']) ?></textarea><br>

    <label for="ngayBatDau">Ngày Bắt Đầu:</label>
    <input type="date" name="ngayBatDau" value="<?= htmlspecialchars($detai['NgayBatDau']) ?>" required><br>

    <label for="ngayKetThuc">Ngày Kết Thúc:</label>
    <input type="date" name="ngayKetThuc" value="<?= htmlspecialchars($detai['NgayKetThuc']) ?>" required><br>

    <label for="nghanh">Ngành:</label>
    <select id="nghanh" name="nghanh" required>
        <?php
        // Kết nối cơ sở dữ liệu
        $pdo = new PDO("mysql:host=localhost;dbname=quanlydoan", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Lấy danh sách ngành
        $query = $pdo->query("SELECT IDNganh, TenNganh FROM nganh");
        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            echo "<option value='{$row['IDNganh']}'>{$row['TenNganh']}</option>";
        }
        ?>
    </select><br><br>

    <label for="giangVien">Giảng Viên:</label>
    <select id="giangVien" name="giangVien" required>
        <?php
        // Lấy danh sách giảng viên
        $query = $pdo->query("SELECT IDGiangVien, HoTen FROM giangvien");
        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            echo "<option value='{$row['IDGiangVien']}'>{$row['HoTen']}</option>";
        }
        ?>
    </select><br><br>

    <label for="loaiDoAn">Loại Đồ Án:</label>
    <select id="loaiDoAn" name="loaiDoAn" required>
        <?php
        // Lấy danh sách loại đồ án
        $query = $pdo->query("SELECT IDLoaiDoAn, TenLoaiDoAn FROM loaidoan");
        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            echo "<option value='{$row['IDLoaiDoAn']}'>{$row['TenLoaiDoAn']}</option>";
        }
        ?>
    </select><br><br>

    <button type="submit">Cập Nhật</button>
</form>
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="../js/sb-admin-2.min.js"></script>