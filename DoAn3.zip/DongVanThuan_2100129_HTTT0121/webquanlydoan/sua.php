<?php
    $pdo = new PDO("mysql:host=localhost;dbname=quanlydoan", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
        $idDeTai = $_GET['id'];
    
        // Lấy thông tin đề tài
        $stmt = $pdo->prepare("SELECT * FROM tiendo WHERE IDTienDo = ?");
        $stmt->execute([$idDeTai]);
        $detai = $stmt->fetch(PDO::FETCH_ASSOC);
    
        if (!$detai) {
            die("Đề tài không tồn tại!");
        }
    }elseif($_SERVER['REQUEST_METHOD'] === 'POST'){
        $idTienDo = $_POST['idTienDo'];
        $tenDeTai = $_POST['TenDeTai'];
        $tenSinhVien = $_POST['HoTen'];
        $tieuDe = $_POST['TieuDeTienDo'];
        $noiDung = $_POST['NoiDungTienDo'];
        $ngayCapNhat = $_POST['NgayCapNhat'];

    // Cập nhật dữ liệu
    $sql = "UPDATE tiendo 
    SET IDDeTai_TienDo = ?, IDSinhVien_TienDo = ?, TieuDeTienDo = ?, NoiDungTienDo = ?, NgayCapNhat= ?, IDGiangVien_DeTai = ?, IDLoaiDoAn_DeTai = ?
    WHERE IDTienDo = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$tenDeTai, $moTa, $ngayBatDau, $ngayKetThuc, $nghanh, $giangVien, $loaiDoAn, $idDeTai]);

    header("Location: detai.php");
    exit;
    }
?>