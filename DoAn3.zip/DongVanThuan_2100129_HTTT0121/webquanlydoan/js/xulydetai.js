
const apiUrl = 'actions.php'; // Đường dẫn đến file PHP xử lý

// Hàm gọi API
const callApi = async (data) => {
    const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    });
    return await response.json();
};

// Xử lý thêm
addBtn.addEventListener('click', async () => {
    const newRow = tableBody.lastElementChild.querySelectorAll('input');
    const data = {
        action: 'add',
        tenDeTai: newRow[0].value,
        moTa: newRow[1].value,
        ngayBatDau: newRow[2].value,
        ngayKetThuc: newRow[3].value,
        nghanh: newRow[4].value,
        giangVien: newRow[5].value,
        loaiDoAn: newRow[6].value,
    };

    const result = await callApi(data);
    alert(result.message);

    if (result.status === 'success') {
        location.reload(); // Làm mới trang để hiển thị dữ liệu mới
    }
});

// Xử lý sửa
editBtn.addEventListener('click', async () => {
    if (!editingRow) return;

    const inputs = editingRow.querySelectorAll('input');
    const data = {
        action: 'edit',
        id: editingRow.dataset.id, // ID lấy từ thuộc tính của hàng
        tenDeTai: inputs[0].value,
        moTa: inputs[1].value,
        ngayBatDau: inputs[2].value,
        ngayKetThuc: inputs[3].value,
        nghanh: inputs[4].value,
        giangVien: inputs[5].value,
        loaiDoAn: inputs[6].value,
    };

    const result = await callApi(data);
    alert(result.message);

    if (result.status === 'success') {
        location.reload(); // Làm mới trang
    }
});

// Xử lý xóa
deleteBtn.addEventListener('click', async () => {
    if (!editingRow) return;

    const data = {
        action: 'delete',
        id: editingRow.dataset.id, // ID lấy từ thuộc tính của hàng
    };

    if (confirm('Bạn có chắc chắn muốn xóa đề tài này?')) {
        const result = await callApi(data);
        alert(result.message);

        if (result.status === 'success') {
            editingRow.remove(); // Xóa trực tiếp trên giao diện
        }
    }
});
