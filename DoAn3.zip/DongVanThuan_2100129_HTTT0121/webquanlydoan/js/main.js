// Lấy các phần tử cần thiết
const navbar = document.getElementById('navbar');
const vanthuanContent = document.querySelector('.content');
const homeButton = document.querySelector('.nav__link:first-child'); // Chọn nút Home (phần tử đầu tiên trong danh sách)

// Lắng nghe sự kiện click trên nút Home
homeButton.addEventListener('click', (event) => {
    event.preventDefault(); // Ngăn chặn hành động mặc định của liên kết
    
    // Chuyển đổi trạng thái menu
    navbar.classList.toggle('navbar-collapsed');
    
    // Chuyển đổi trạng thái nội dung
    vanthuanContent.classList.toggle('content-collapsed');
});



