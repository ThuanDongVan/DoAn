// Hàm cập nhật ngày tháng theo định dạng "Thứ Hai, ngày 12 tháng 2 năm 2024"
function updateDateDisplay() {
    const dateDisplay = document.getElementById("dateDisplay");
    const now = new Date();

    // Lấy thông tin ngày, tháng, năm
    const daysOfWeek = [
        "Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"
    ];
    const months = [
        "tháng 1", "tháng 2", "tháng 3", "tháng 4", "tháng 5", "tháng 6",
        "tháng 7", "tháng 8", "tháng 9", "tháng 10", "tháng 11", "tháng 12"
    ];

    const dayOfWeek = daysOfWeek[now.getDay()];
    const date = now.getDate();
    const month = months[now.getMonth()];
    const year = now.getFullYear();

    // Hiển thị ngày tháng theo định dạng
    dateDisplay.textContent = `${dayOfWeek}, ngày ${date} ${month} năm ${year}`;
}

// Gọi hàm khi tải trang
updateDateDisplay();
