// Kiểm tra quyền của người dùng
fetch('phanquyen.php') // Tệp PHP kiểm tra quyền
    .then(response => response.json())
    .then(data => {
        const isAdmin = data.isAdmin;

        // Kiểm tra vai trò và thay đổi nút tương ứng
        const confirmButton = document.getElementById('confirmButton');
        
        // Nếu là admin, thay thế nút xác nhận thành Duyệt đồ án
        if (isAdmin) {
            // Thêm nút "Duyệt đồ án"
            if (confirmButton) {
                confirmButton.textContent = 'Duyệt đồ án';
                confirmButton.classList.remove('btn-success');
                confirmButton.classList.add('btn-info');
                confirmButton.setAttribute('onclick', 'approveItem()');
            }
        } else {
            // Nếu không phải admin, giữ nút "Xác nhận"
            if (confirmButton) {
                confirmButton.textContent = 'Xác nhận';
                confirmButton.classList.remove('btn-info');
                confirmButton.classList.add('btn-success');
                confirmButton.setAttribute('onclick', 'confirmSelection()');
            }
        }

        // Hiển thị các nút "Thêm", "Sửa", "Xóa" nếu là admin
        if (isAdmin) {
            const header = document.querySelector('.card-header');
            const adminButtons = `
                <button class="btn btn-primary" onclick="addItem()">Thêm</button>
                <button class="btn btn-warning" onclick="editItem()">Sửa</button>
                <button class="btn btn-danger" onclick="deleteItem()">Xóa</button>
            `;
            header.insertAdjacentHTML('beforeend', adminButtons);
        }
    })
    .catch(error => console.error('Lỗi:', error));

