document.addEventListener("DOMContentLoaded", () => {
    const tableBody = document.getElementById("table-body");
    const selectedTableBody = document.querySelector("#selectedTable tbody");

    // Xử lý sự kiện click trên hàng
    tableBody.addEventListener("click", (event) => {
        const row = event.target.closest("tr");
        if (row) {
            // Hiển thị thông báo xác nhận
            const confirmSelection = confirm("Bạn có muốn chọn đề tài này không?");
            if (confirmSelection) {
                // Sao chép dữ liệu từ hàng được chọn
                const rowData = Array.from(row.children).map((cell) => cell.innerText);

                // Tạo một hàng mới cho bảng "Danh sách đồ án đã chọn"
                const newRow = document.createElement("tr");
                newRow.innerHTML = `
                    <td>${rowData[0]}</td>
                    <td>${rowData[1]}</td>
                    <td>${rowData[2]}</td>
                    <td>${rowData[3]}</td>
                    <td>${rowData[4]}</td>
                    <td>${rowData[5]}</td>
                    <td>${rowData[6]}</td>
                    <td class="status-cell">Chờ phê duyệt</td>
                `;

                // Thêm hàng mới vào bảng
                selectedTableBody.appendChild(newRow);
            }
        }
    });

    // Chỉ giảng viên mới có quyền phê duyệt
    selectedTableBody.addEventListener("click", (event) => {
        const statusCell = event.target.closest(".status-cell");
        if (statusCell) {
            // Hiển thị thông báo xác nhận
            const confirmApproval = confirm("Bạn có muốn phê duyệt đề tài này không?");
            if (confirmApproval) {
                statusCell.textContent = "Đã phê duyệt"; // Cập nhật trạng thái
            }
        }
    });
});
