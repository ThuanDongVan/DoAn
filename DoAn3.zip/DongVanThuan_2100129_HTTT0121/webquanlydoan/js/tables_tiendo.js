let row = null; // Lưu trữ hàng được chọn

// Hàm chọn hàng
function selectRow(row) {
    if (row) {
        row.classList.remove('table-primary'); // Bỏ màu nếu đã chọn
    }
    row = row;
    row.classList.add('table-primary'); // Thêm màu nổi bật
}

let is = false; // Kiểm tra trạng thái khi thêm hàng mới


let selectedRow = null; // Lưu trữ hàng được chọn
let isEditing = false; // Kiểm tra trạng thái khi thêm hàng mới
let currentRow = null; // Lưu trữ hàng đang được chỉnh sửa

// Hàm chọn hàng
function selectRow(row) {
    if (selectedRow) {
        selectedRow.classList.remove('table-primary'); // Bỏ màu nếu đã chọn
    }
    selectedRow = row;
    selectedRow.classList.add('table-primary'); // Thêm màu nổi bật
}

// Hàm thêm hàng mới hoặc sửa hàng đã có
function addRow() {
    const table = document.getElementById('dataTable').getElementsByTagName('tbody')[0];

    // Nếu đang trong trạng thái sửa, không cho thêm hàng mới
    if (isEditing) {
        saveRow(); // Lưu hàng hiện tại khi đang chỉnh sửa
        return;
    }

    // Lấy ngày hiện tại
    const now = new Date();
    const currentDate = `${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}`;

    // Tạo hàng mới
    const newRow = table.insertRow();
    newRow.onclick = () => selectRow(newRow);

    // Tạo ô nhập tiêu đề
    const titleCell = newRow.insertCell();
    const titleInput = document.createElement('input');
    titleInput.type = 'text';
    titleInput.placeholder = 'Nhập tiêu đề';
    titleInput.className = 'form-control';
    titleCell.appendChild(titleInput);

    // Tạo ô upload file
    const fileCell = newRow.insertCell();
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.className = 'form-control';
    fileCell.appendChild(fileInput);

    // Tạo ô hiển thị ngày không chỉnh sửa
    const dateCell = newRow.insertCell();
    dateCell.textContent = currentDate;
    dateCell.className = 'text-center'; // Canh giữa nội dung

    // Lưu lại hàng đang được thêm
    currentRow = newRow;
    isEditing = true; // Đặt trạng thái chỉnh sửa
    document.querySelector('.btn-success').textContent = 'Lưu'; // Thay đổi nút "Thêm" thành "Lưu"
}

// Hàm lưu hàng khi nhấn nút "Lưu"
function saveRow() {
    if (!currentRow) {
        return;
    }

    const titleInput = currentRow.cells[0].querySelector('input');
    const fileInput = currentRow.cells[1].querySelector('input');
    
    const title = titleInput.value.trim();
    const fileName = fileInput.value.split('\\').pop().trim(); // Lấy tên file

    if (!title) {
        alert('Vui lòng nhập tiêu đề!');
        return;
    }

    if (!fileName) {
        alert('Vui lòng chọn tệp!');
        return;
    }

    // Lưu dữ liệu vào các ô và chuyển đổi thành văn bản
    currentRow.cells[0].textContent = title;
    currentRow.cells[1].textContent = fileName;

    // Đặt lại trạng thái
    document.querySelector('.btn-success').textContent = 'Thêm'; // Đổi nút "Lưu" thành "Thêm"
    isEditing = false;
    currentRow = null; // Reset hàng đang chỉnh sửa
}


// Hàm sửa hàng được chọn
function editRow() {
    if (!selectedRow) {
        alert('Vui lòng chọn một hàng để sửa!');
        return;
    }

    // Lấy các ô trong hàng được chọn
    const cells = selectedRow.getElementsByTagName('td');

    // Kiểm tra xem cột đã có ô nhập liệu hay chưa
    if (cells[0].querySelector('input')) {
        // Nếu đã có ô nhập liệu, chuyển dữ liệu từ ô nhập thành text
        const titleInput = cells[0].querySelector('input');
        const fileInput = cells[1].querySelector('input');

        const title = titleInput.value || 'Tiêu đề rỗng';
        const file = fileInput.value.split('\\').pop() || 'Chưa tải file';

        cells[0].textContent = title;
        cells[1].textContent = file;
    } else {
        // Nếu chưa có ô nhập liệu, chuyển thành ô nhập liệu để chỉnh sửa
        const title = cells[0].textContent;
        const file = cells[1].textContent;

        cells[0].innerHTML = `<input type="text" class="form-control" value="${title}">`;
        cells[1].innerHTML = `<input type="file" class="form-control">`;
    }
}
// Hàm xóa hàng được chọn
function deleteRow() {
    if (!selectedRow) {
        alert('Vui lòng chọn một hàng để xóa!');
        return;
    }

    // Hiển thị hộp thoại xác nhận
    const confirmDelete = confirm('Bạn có chắc chắn muốn xóa hàng này không?');
    if (confirmDelete) {
        selectedRow.remove(); // Xóa hàng khỏi bảng
        selectedRow = null; // Đặt lại biến hàng được chọn
    }
}

