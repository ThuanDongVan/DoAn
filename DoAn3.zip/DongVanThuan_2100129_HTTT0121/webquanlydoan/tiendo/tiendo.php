<?php
session_start();
// Include các file cần thiết để kết nối cơ sở dữ liệu (tùy thuộc vào cách bạn cài đặt)
$servername = "localhost"; // Hoặc IP của máy chủ cơ sở dữ liệu
$username = "root";        // Tên người dùng cơ sở dữ liệu
$password = "";            // Mật khẩu cơ sở dữ liệu
$dbname = "quanlydoan";    // Tên cơ sở dữ liệu bạn muốn kết nối

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Hàm để lấy dữ liệu từ cơ sở dữ liệu
function getTienDo()
{
    global $conn;
    $sql = "SELECT 
        *
    FROM 
        tiendo
    JOIN 
        detai ON tiendo.IDDeTai_TienDo = detai.IDDeTai
    JOIN 
        sinhvien ON tiendo.IDSinhVien_TienDo = sinhvien.IDSinhVien;   
    ";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tiến độ</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/tiendo.css">
    <!-- Custom fonts for this template -->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        .action-buttons {
                display: flex;
                /* Sử dụng flexbox để căn ngang */
                align-items: center;
                /* Căn giữa theo chiều dọc */
                gap: 10px;
                /* Tạo khoảng cách giữa các nút */
            }

            .action-buttons button {
                margin: 0;
                /* Loại bỏ margin mặc định */
                padding: 10px 20px;
                /* Đặt padding tùy ý */
                font-size: 16px;
                /* Đặt kích thước chữ */
            }
        tr.selected {
            background-color: #ffe5e5;
            /* Màu nền nổi bật */
            color: #d9534f;
            /* Màu chữ */
        }
    </style>
</head>

<body id="body" data-role="<?php echo $_SESSION['VaiTro']; ?>">
    <div class="l-navbar navbar-collapsed" id="navbar">
        <div class="nav">
            <div>
                <a href="../index.html" class="nav__logo">
                    <img src="../logo-ctut-300x300.png" alt="" class="nav__logo-icon">
                    <span class="nav__logo-text"></span>
                </a>
                <ul class="nav__list" style="padding-right: 0px; padding-left: 0px;">
                    <a href="../index.html" class="nav__link active">
                        <i class='bx bx-grid-alt nav__icon'></i>
                        <span class="nav__text">Home</span>
                    </a>
                    <a href="../detai/detai.php" class="nav__link active">
                        <i class='bx bx-receipt nav__icon'></i>
                        <span class="nav__text">Đề Tài</span>
                    </a>
                    <a href="tiendo.php" class="nav__link active">
                        <i class='bx bx-time-five nav__icon'></i>
                        <span class="nav__text">Tiến Độ</span>
                    </a>
                    <a href="../thongbao/thongbao.php" class="nav__link active">
                        <i class='bx bx-bell nav__icon'></i>
                        <span class="nav__text">Thông Báo</span>
                    </a>
                    <a href="../danhgia/danhgia.php" class="nav__link active">
                        <i class='bx bx-check-circle nav__icon'></i>
                        <span class="nav__text">Đánh Giá</span>
                    </a>
                </ul>
            </div>
            <a href="../login.html" class="nav__link active">
                <i class='bx bx-log-out-circle nav__icon'></i>
                <span class="nav__text">Đăng Xuất</span>
            </a>
        </div>
    </div>
    <div class="banner content content-collapsed" style="padding-top: 0px;">
        <div class="bg">
            <header class="bg-blue-800 text-white py-2">
                <div class="container mx-auto flex justify-between items-center px-4">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-clock"></i>
                        <span id="dateDisplay"></span> <!-- Phần tử để hiển thị ngày -->
                    </div>
                    <div>
                        <a href="https://facebook.com" target="_blank" class="hover:text-blue-300">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </div>
                </div>
            </header>
        </div>
        <img alt="University banner with text 'TRƯz`ỜNG ĐẠI HỌC KỸ THUẬT - CÔNG NGHỆ CẦN THƠ KHOA CÔNG NGHỆ THÔNG TIN'"
            height="200" src="../cropped-banner_web.png" width="1300" />
        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800">Danh sách tiến độ</h1>
            <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                For more information about DataTables, please visit the.</p> -->

            <!-- DataTales Example -->
            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Danh sách tiến độ</h6>
                    <div class="action-buttons">
                        <button id="add-btn" class="btn btn-success">Thêm</button>
                        <button id="edit-btn" class="btn btn-warning">Sửa</button>
                        <button id="delete-btn" class="btn btn-danger">Xóa</button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <form id="addForm" method="POST" action="them.php">
                            <table class="table table-bordered" id="dataTable">
                                <thead>
                                    <tr>
                                        <th>Tiêu đề</th>
                                        <th>Nội dung</th>
                                        <th>Tên đề tài</th>
                                        <th>Sinh viên thực hiện</th>
                                        <th>Ngày nộp</th>
                                        <th>Hành động</th>
                                    </tr>
                                </thead>
                                <tbody id="table-body">
                                    <!-- Dữ liệu sẽ được thêm động ở đây -->
                                </tbody>
                            </table>
                            <button type="submit" class="btn btn-success">Lưu</button>
                        </form>
                        <h3 class="mt-5">Danh sách tiến độ</h3>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Tiêu đề</th>
                                    <th>Nội dung</th>
                                    <th>Tên đề tài</th>
                                    <th>Sinh viên thực hiện</th>
                                    <th>Ngày nộp</th>
                                </tr>
                            </thead>
                            <tbody id="tables-body">
                                <?php
                                $tiendos = getTienDo($conn);
                                if (!empty($tiendos)) {
                                    foreach ($tiendos as $tiendo) {
                                        echo "<tr data-id='{$tiendo['IDTienDo']}'>
                            <td>{$tiendo['TieuDeTienDo']}</td>
                            <td>{$tiendo['NoiDungTienDo']}</td>
                            <td>{$tiendo['TenDeTai']}</td>
                            <td>{$tiendo['HoTen']}</td>
                            <td>{$tiendo['NgayCapNhat']}</td>
                        </tr>";
                                    }
                                } else {
                                    echo '<tr><td colspan="5">Không có dữ liệu</td></tr>';
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <p>KHOA CÔNG NGHỆ THÔNG TIN</p>
            <p>Trường Đại học Kỹ thuật - Công nghệ Cần Thơ</p>
            <p>SĐT Khoa: 071.0389.7574</p>

            <p>FanPage: <a href="http://fb.com/cnttdhktcnct">fb.com/cnttdhktcnct/</a></p>
            <p>Email: <a href="mailto:gkhoacntt@cutet.edu.vn">khoacntt@ctuet.edu.vn/</a></p>
        </div>
    </div>
    <script>
        const addBtn = document.getElementById("add-btn");
        const tableBody = document.getElementById("table-body");

        // Khi nhấn nút "Thêm tiến độ"
        addBtn.addEventListener("click", () => {
            const row = tableBody.insertRow();

            row.innerHTML = `
                <td><input type="text" name="TieuDe[]" class="form-control" placeholder="Nhập tiêu đề" required></td>
                <td><input type="text" name="NoiDung[]" class="form-control" placeholder="Nhập nội dung" required></td>
                <td>
                    <select name="TenDeTai[]" class="form-control" required>
                        <option value="">Chọn đề tài</option>
                        <?php
                        $detaiList = $conn->query("SELECT IDDeTai, TenDeTai FROM detai");
                        while ($row = $detaiList->fetch_assoc()) {
                            echo "<option value='{$row['IDDeTai']}'>{$row['TenDeTai']}</option>";
                        }
                        ?>
                    </select>
                </td>
                <td>
                    <select name="HoTen[]" class="form-control" required>
                        <option value="">Chọn sinh viên</option>
                        <?php
                        $sinhvienList = $conn->query("SELECT IDSinhVien, HoTen FROM sinhvien");
                        while ($row = $sinhvienList->fetch_assoc()) {
                            echo "<option value='{$row['IDSinhVien']}'>{$row['HoTen']}</option>";
                        }
                        ?>
                    </select>
                </td>
                <td><input type="date" name="NgayCapNhat[]" class="form-control" required></td>
                <td><button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">Xóa</button></td>
            `;
        });

        // Hàm xóa hàng
        function removeRow(button) {
            const row = button.closest('tr');
            row.remove();
        }
    </script>
    <!-- Sửa -->
    <script>
        // Nút "Sửa"
        const editBtn = document.getElementById("edit-btn");
        editBtn.addEventListener("click", () => {
            if (selectedRows.length !== 1) {
                alert("Vui lòng chọn một dòng duy nhất để sửa.");
                return;
            }

            // Chuyển hướng đến trang sửa với ID đã chọn
            const id = selectedRows[0];
            window.location.href = `formsua.php?id=${id}`;
        });
    </script>
    <script>
        const tablesBody = document.getElementById("tables-body");
        // Chức năng chọn dòng
        let selectedRows = [];

        tablesBody.addEventListener("click", (event) => {
            const row = event.target.closest("tr");
            if (row) {
                row.classList.toggle("selected"); // Bật/tắt trạng thái chọn
                const id = row.getAttribute("data-id");
                if (row.classList.contains("selected")) {
                    selectedRows.push(id); // Thêm ID dòng vào danh sách đã chọn
                } else {
                    selectedRows = selectedRows.filter((item) => item !== id); // Loại bỏ ID khỏi danh sách đã chọn
                }
            }
        });


        // Nút "Xóa"
        const deleteBtn = document.getElementById("delete-btn");
        deleteBtn.addEventListener("click", () => {
            if (selectedRows.length === 0) {
                alert("Vui lòng chọn ít nhất một dòng để xóa.");
                return;
            }

            if (confirm(`Bạn có chắc chắn muốn xóa ${selectedRows.length} đề tài đã chọn?`)) {
                // Gửi yêu cầu xóa đến server
                const formData = new FormData();
                formData.append("action", "delete");
                formData.append("ids", selectedRows.join(","));

                fetch("xoa.php", {
                        method: "POST",
                        body: formData,
                    })
                    .then((response) => response.text())
                    .then((data) => {
                        alert(data); // Hiển thị thông báo từ server
                        location.reload(); // Reload lại trang
                    })
                    .catch((error) => console.error("Lỗi:", error));
            }
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const role = document.body.getAttribute("data-role");
            if (role === "SinhVien") {
                document.getElementById("add-btn").style.display = "block";
                document.getElementById("delete-btn").style.display = "block";
                document.getElementById("edit-btn").style.display = "block";
            } else if (role === "GiangVien") {
                document.getElementById("addForm").style.display = "none";
                document.getElementById("edit-btn").style.display = "none";
                document.getElementById("add-btn").style.display = "none";
                document.getElementById("delete-btn").style.display = "none";
            }
        });
    </script>
    <script src="../js/main.js"></script>
    <script src="../js/date.js"></script>
    <!-- <script src="../js/tables_tiendo.js"></script> -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>