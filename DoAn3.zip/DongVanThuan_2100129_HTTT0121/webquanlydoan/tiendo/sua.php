<?php
$pdo = new PDO("mysql:host=localhost;dbname=quanlydoan", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $idDeTai = $_GET['id'];

    // Lấy thông tin đề tài
    $stmt = $pdo->prepare("SELECT * FROM tiendo WHERE IDTienDo = ?");
    $stmt->execute([$idDeTai]);
    $detai = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$detai) {
        die("Tiến độ không tồn tại!");
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idTienDo = $_POST['idTienDo'];
    $tieuDe = $_POST['tieuDe'];
    $noiDung = $_POST['noiDung'];
    $tenDeTai = $_POST['tenDeTai'];
    $sinhVienThucHien = $_POST['sinhVienThucHien'];
    $ngayNop = $_POST['ngayNop'];

    // Cập nhật dữ liệu
    $sql = "UPDATE tiendo 
            SET IDDeTai_TienDo = ?, IDSinhVien_TienDo = ?, TieuDeTienDo = ?, NoiDungTienDo = ?, NgayCapNhat = ?
            WHERE IDTienDo = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$tenDeTai, $sinhVienThucHien, $tieuDe, $noiDung, $ngayNop, $idTienDo]);

    header("Location: tiendo.php");
    exit;
}
?>