<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tenDeTai = $_POST['TenDeTai'];
    $sinhVienThucHien = $_POST['HoTen'];
    $tieude = $_POST['TieuDe'];
    $NoiDung = $_POST['NoiDung'];
    $ngayCapNhat = $_POST['NgayCapNhat'];

    $mysqli = new mysqli('localhost', 'root', '', 'quanlydoan');
    if ($mysqli->connect_error) {
        die('Kết nối thất bại: ' . $mysqli->connect_error);
    }

    for ($i = 0; $i < count($tieude); $i++) {
        if (empty($tenDeTai[$i]) || empty($sinhVienThucHien[$i]) || empty($tieude[$i]) || empty($ngayCapNhat[$i])) {
            echo "Lỗi: Tất cả các trường đều phải được điền!";
            exit;
        }

        $stmt = $mysqli->prepare("INSERT INTO tiendo (IDDeTai_TienDo, IDSinhVien_TienDo, TieuDeTienDo, NoiDungTienDo, NgayCapNhat) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $tenDeTai[$i], $sinhVienThucHien[$i], $tieude[$i], $NoiDung[$i], $ngayCapNhat[$i]);

        if (!$stmt->execute()) {
            echo "Lỗi: " . $stmt->error;
            exit;
        }
    }

    $stmt->close();
    $mysqli->close();

    header('Location: tiendo.php');
}
?>
