<?php
session_start();

// Xóa tất cả các session
session_unset();
session_destroy();

// Xóa cookies nếu có
if (isset($_COOKIE['user_login'])) {
    setcookie('user_login', '', time() - 3600, '/');
}

// Ngừng trình duyệt lưu bộ nhớ cache của trang
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); // Đặt ngày hết hạn trong quá khứ
header("Pragma: no-cache");

// Chuyển hướng người dùng đến trang đăng nhập hoặc trang chủ
header('Location: login.html');
exit;
?>
