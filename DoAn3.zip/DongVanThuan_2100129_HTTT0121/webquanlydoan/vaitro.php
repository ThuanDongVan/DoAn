<?php
session_start();
if (!isset($_SESSION['email']) || !isset($_SESSION['VaiTro'])) {
    // Nếu chưa đăng nhập, chuyển hướng về trang đăng nhập
    header("Location: login.html");
    exit();
}

// Lấy vai trò từ session
$email = $_SESSION['email'];
$VaiTro = $_SESSION['VaiTro'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chính</title>
</head>
<body>
    <h1>Chào mừng bạn, <?php echo htmlspecialchars($email); ?>!</h1>
    <p>Vai trò của bạn: <strong><?php echo htmlspecialchars($VaiTro); ?></strong></p>
    <a href="logout.php">Đăng xuất</a>
</body>
</html>
