<?php
$servername = "localhost"; // Hoặc IP của máy chủ cơ sở dữ liệu
$username = "root";        // Tên người dùng cơ sở dữ liệu
$password = "";            // Mật khẩu cơ sở dữ liệu
$dbname = "quanlydoan";    // Tên cơ sở dữ liệu bạn muốn kết nối

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
