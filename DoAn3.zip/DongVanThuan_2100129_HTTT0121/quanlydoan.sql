-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th1 05, 2025 lúc 04:27 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `quanlydoan`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danhgiacuagiangvien`
--

CREATE TABLE `danhgiacuagiangvien` (
  `IDDanhGia` int(11) NOT NULL,
  `IDDeTai_DGGV` int(11) NOT NULL,
  `IDGiangVien_DGGV` int(11) NOT NULL,
  `NoiDungDanhGia` text DEFAULT NULL,
  `DiemSo` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danhgiacuagiangvien`
--

INSERT INTO `danhgiacuagiangvien` (`IDDanhGia`, `IDDeTai_DGGV`, `IDGiangVien_DGGV`, `NoiDungDanhGia`, `DiemSo`) VALUES
(1, 1, 1, 'Đề tài được thực hiện tốt, đạt yêu cầu.', 8.50),
(2, 2, 2, 'Cần cải thiện nội dung nghiên cứu.', 7.00);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `detai`
--

CREATE TABLE `detai` (
  `IDDeTai` int(11) NOT NULL,
  `IDGiangVien_DeTai` int(11) NOT NULL,
  `IDNganh_DeTai` int(11) NOT NULL,
  `IDLoaiDoAn_DeTai` int(11) NOT NULL,
  `TenDeTai` varchar(255) NOT NULL,
  `MoTa` text DEFAULT NULL,
  `NgayBatDau` date DEFAULT NULL,
  `NgayKetThuc` date DEFAULT NULL,
  `TrangThai` enum('Chờ xét duyệt','Đã xét duyệt','Không xét duyệt') NOT NULL DEFAULT 'Chờ xét duyệt',
  `NgayChon` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `detai`
--

INSERT INTO `detai` (`IDDeTai`, `IDGiangVien_DeTai`, `IDNganh_DeTai`, `IDLoaiDoAn_DeTai`, `TenDeTai`, `MoTa`, `NgayBatDau`, `NgayKetThuc`, `TrangThai`, `NgayChon`) VALUES
(1, 1, 4, 4, 'Phát triển ứng dụng web', 'Nghiên cứu và phát triển ứng dụng web thương mại điện tử.', '2024-01-01', '2024-06-30', 'Chờ xét duyệt', '2024-12-09'),
(2, 2, 2, 2, 'Xử lý ngôn ngữ tự nhiên', 'Phân tích cảm xúc trong các bài đăng mạng xã hội.', '2024-02-01', '2024-07-30', 'Chờ xét duyệt', '2024-12-17'),
(20, 1, 1, 2, 'Winform', 'Làm bằng window form', '2024-12-18', '2024-12-28', 'Chờ xét duyệt', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `giangvien`
--

CREATE TABLE `giangvien` (
  `IDGiangVien` int(11) NOT NULL,
  `IDNganh_GiangVien` int(11) NOT NULL,
  `HoTen` varchar(255) NOT NULL,
  `NgaySinh` date DEFAULT NULL,
  `GioiTinh` enum('Nam','Nu') NOT NULL,
  `Email` varchar(255) NOT NULL,
  `SDT` varchar(15) DEFAULT NULL,
  `HocVi` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `giangvien`
--

INSERT INTO `giangvien` (`IDGiangVien`, `IDNganh_GiangVien`, `HoTen`, `NgaySinh`, `GioiTinh`, `Email`, `SDT`, `HocVi`) VALUES
(1, 1, 'Nguyễn Văn Tùng', '1980-01-15', 'Nam', 'nguyenvantung@example.com', '0123456789', 'Tiến sĩ'),
(2, 2, 'Trần Thị Hoa', '1985-06-20', 'Nu', 'tranthihoa@example.com', '0987654321', 'Thạc sĩ'),
(3, 3, 'Lê Văn Đức', '1975-09-05', 'Nam', 'levanduc@example.com', '0167891234', 'Giáo sư');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loaidoan`
--

CREATE TABLE `loaidoan` (
  `IDLoaiDoAn` int(11) NOT NULL,
  `TenLoaiDoAn` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `loaidoan`
--

INSERT INTO `loaidoan` (`IDLoaiDoAn`, `TenLoaiDoAn`) VALUES
(1, 'Đồ án tốt nghiệp'),
(2, 'Đồ án học phần 1'),
(3, 'Đồ án học phần 3'),
(4, 'Đồ án học phần 2'),
(5, 'Đồ án học phần 4');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nganh`
--

CREATE TABLE `nganh` (
  `IDNganh` int(11) NOT NULL,
  `TenNganh` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nganh`
--

INSERT INTO `nganh` (`IDNganh`, `TenNganh`) VALUES
(1, 'Công nghệ thông tin'),
(2, 'Khoa học máy tính'),
(3, 'Kỹ thuật phần mềm'),
(4, 'Hệ thống thông tin'),
(5, 'Khoa học dữ liệu');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sinhvien`
--

CREATE TABLE `sinhvien` (
  `IDSinhVien` int(11) NOT NULL,
  `HoTen` varchar(255) NOT NULL,
  `NgaySinh` date DEFAULT NULL,
  `GioiTinh` enum('Nam','Nu') NOT NULL,
  `Email` varchar(255) NOT NULL,
  `SDT` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `sinhvien`
--

INSERT INTO `sinhvien` (`IDSinhVien`, `HoTen`, `NgaySinh`, `GioiTinh`, `Email`, `SDT`) VALUES
(1, 'Phạm Văn Được', '2000-05-10', 'Nam', 'phamvanduoc@example.com', '0345678912'),
(2, 'Nguyễn Thị Thúy', '1999-12-25', 'Nu', 'nguyenthithuy@example.com', '0123456788'),
(3, 'Lê Văn Sinh', '2001-03-15', 'Nam', 'levansinh@example.com', '0112233445');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sinhvien_chondetai`
--

CREATE TABLE `sinhvien_chondetai` (
  `ID` int(11) NOT NULL,
  `IDGiangVien_DTDC` int(11) NOT NULL,
  `IDNganh_DTDC` int(11) NOT NULL,
  `IDLoaiDoAn_DTDC` int(11) NOT NULL,
  `TenDeTai` varchar(255) NOT NULL,
  `MoTa` text NOT NULL,
  `NgayBatDau` date NOT NULL,
  `NgayKetThuc` date NOT NULL,
  `TrangThai` varchar(50) DEFAULT NULL,
  `NgayChon` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thongbao`
--

CREATE TABLE `thongbao` (
  `IDThongBao` int(11) NOT NULL,
  `IDGiangVien_ThongBao` int(11) NOT NULL,
  `TieuDe` varchar(255) NOT NULL,
  `NoiDung` text DEFAULT NULL,
  `NgayTao` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `thongbao`
--

INSERT INTO `thongbao` (`IDThongBao`, `IDGiangVien_ThongBao`, `TieuDe`, `NoiDung`, `NgayTao`) VALUES
(1, 1, 'Thông báo về đồ án tốt nghiệp', 'Sinh viên hoàn thành đề cương đồ án trước ngày 20/12/2024.', '2024-12-01'),
(2, 2, 'Cập nhật tiến độ đồ án', 'Hãy nộp tiến độ đồ án lần 1 trước ngày 15/01/2024.', '2024-12-02');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tiendo`
--

CREATE TABLE `tiendo` (
  `IDTienDo` int(11) NOT NULL,
  `IDDeTai_TienDo` int(11) NOT NULL,
  `IDSinhVien_TienDo` int(11) NOT NULL,
  `TieuDeTienDo` varchar(255) NOT NULL,
  `NoiDungTienDo` text DEFAULT NULL,
  `NgayCapNhat` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `tiendo`
--

INSERT INTO `tiendo` (`IDTienDo`, `IDDeTai_TienDo`, `IDSinhVien_TienDo`, `TieuDeTienDo`, `NoiDungTienDo`, `NgayCapNhat`) VALUES
(1, 1, 1, 'Hoàn thành đề cương', 'Sinh viên đã hoàn thành đề cương và được giảng viên phê duyệt.', '2024-01-10'),
(2, 2, 2, 'Tiến độ nghiên cứu', 'Đã hoàn thành thu thập dữ liệu cho đề tài.', '2024-02-20');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `IDGiangVien` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `VaiTro` enum('Admin','GiangVien','SinhVien') NOT NULL,
  `IDSinhVien` int(11) DEFAULT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`IDGiangVien`, `Email`, `Password`, `VaiTro`, `IDSinhVien`, `ID`) VALUES
(2, 'giangvien@example.com', 'giangvien', 'GiangVien', 1, 1),
(1, 'sinhvien@example.com', 'sinhvien', 'SinhVien', 3, 3);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `danhgiacuagiangvien`
--
ALTER TABLE `danhgiacuagiangvien`
  ADD PRIMARY KEY (`IDDanhGia`),
  ADD KEY `IDDeTai_DGGV` (`IDDeTai_DGGV`),
  ADD KEY `IDGiangVien_DGGV` (`IDGiangVien_DGGV`);

--
-- Chỉ mục cho bảng `detai`
--
ALTER TABLE `detai`
  ADD PRIMARY KEY (`IDDeTai`),
  ADD KEY `IDGiangVien_DeTai` (`IDGiangVien_DeTai`),
  ADD KEY `IDNganh_DeTai` (`IDNganh_DeTai`),
  ADD KEY `IDLoaiDoAn_DeTai` (`IDLoaiDoAn_DeTai`);

--
-- Chỉ mục cho bảng `giangvien`
--
ALTER TABLE `giangvien`
  ADD PRIMARY KEY (`IDGiangVien`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `IDNganh_GiangVien` (`IDNganh_GiangVien`);

--
-- Chỉ mục cho bảng `loaidoan`
--
ALTER TABLE `loaidoan`
  ADD PRIMARY KEY (`IDLoaiDoAn`);

--
-- Chỉ mục cho bảng `nganh`
--
ALTER TABLE `nganh`
  ADD PRIMARY KEY (`IDNganh`);

--
-- Chỉ mục cho bảng `sinhvien`
--
ALTER TABLE `sinhvien`
  ADD PRIMARY KEY (`IDSinhVien`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Chỉ mục cho bảng `sinhvien_chondetai`
--
ALTER TABLE `sinhvien_chondetai`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `IDLoaiDoAn_DTDC` (`IDLoaiDoAn_DTDC`),
  ADD KEY `IDGiangVien_DTDC` (`IDGiangVien_DTDC`),
  ADD KEY `IDNganh_DTDC` (`IDNganh_DTDC`);

--
-- Chỉ mục cho bảng `thongbao`
--
ALTER TABLE `thongbao`
  ADD PRIMARY KEY (`IDThongBao`),
  ADD KEY `IDGiangVien_ThongBao` (`IDGiangVien_ThongBao`);

--
-- Chỉ mục cho bảng `tiendo`
--
ALTER TABLE `tiendo`
  ADD PRIMARY KEY (`IDTienDo`),
  ADD KEY `IDDeTai_TienDo` (`IDDeTai_TienDo`),
  ADD KEY `IDSinhVien_TienDo` (`IDSinhVien_TienDo`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `IDSinhVien` (`IDSinhVien`),
  ADD KEY `IDGiangVien` (`IDGiangVien`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `danhgiacuagiangvien`
--
ALTER TABLE `danhgiacuagiangvien`
  MODIFY `IDDanhGia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT cho bảng `detai`
--
ALTER TABLE `detai`
  MODIFY `IDDeTai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT cho bảng `giangvien`
--
ALTER TABLE `giangvien`
  MODIFY `IDGiangVien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `loaidoan`
--
ALTER TABLE `loaidoan`
  MODIFY `IDLoaiDoAn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT cho bảng `nganh`
--
ALTER TABLE `nganh`
  MODIFY `IDNganh` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT cho bảng `sinhvien`
--
ALTER TABLE `sinhvien`
  MODIFY `IDSinhVien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `sinhvien_chondetai`
--
ALTER TABLE `sinhvien_chondetai`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT cho bảng `thongbao`
--
ALTER TABLE `thongbao`
  MODIFY `IDThongBao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `tiendo`
--
ALTER TABLE `tiendo`
  MODIFY `IDTienDo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `danhgiacuagiangvien`
--
ALTER TABLE `danhgiacuagiangvien`
  ADD CONSTRAINT `danhgiacuagiangvien_ibfk_1` FOREIGN KEY (`IDDeTai_DGGV`) REFERENCES `detai` (`IDDeTai`),
  ADD CONSTRAINT `danhgiacuagiangvien_ibfk_2` FOREIGN KEY (`IDGiangVien_DGGV`) REFERENCES `giangvien` (`IDGiangVien`);

--
-- Các ràng buộc cho bảng `detai`
--
ALTER TABLE `detai`
  ADD CONSTRAINT `detai_ibfk_1` FOREIGN KEY (`IDGiangVien_DeTai`) REFERENCES `giangvien` (`IDGiangVien`),
  ADD CONSTRAINT `detai_ibfk_2` FOREIGN KEY (`IDNganh_DeTai`) REFERENCES `nganh` (`IDNganh`),
  ADD CONSTRAINT `detai_ibfk_3` FOREIGN KEY (`IDLoaiDoAn_DeTai`) REFERENCES `loaidoan` (`IDLoaiDoAn`);

--
-- Các ràng buộc cho bảng `giangvien`
--
ALTER TABLE `giangvien`
  ADD CONSTRAINT `giangvien_ibfk_1` FOREIGN KEY (`IDNganh_GiangVien`) REFERENCES `nganh` (`IDNganh`);

--
-- Các ràng buộc cho bảng `sinhvien_chondetai`
--
ALTER TABLE `sinhvien_chondetai`
  ADD CONSTRAINT `sinhvien_chondetai_ibfk_1` FOREIGN KEY (`IDGiangVien_DTDC`) REFERENCES `giangvien` (`IDGiangVien`),
  ADD CONSTRAINT `sinhvien_chondetai_ibfk_2` FOREIGN KEY (`IDNganh_DTDC`) REFERENCES `nganh` (`IDNganh`),
  ADD CONSTRAINT `sinhvien_chondetai_ibfk_3` FOREIGN KEY (`IDLoaiDoAn_DTDC`) REFERENCES `loaidoan` (`IDLoaiDoAn`);

--
-- Các ràng buộc cho bảng `thongbao`
--
ALTER TABLE `thongbao`
  ADD CONSTRAINT `thongbao_ibfk_1` FOREIGN KEY (`IDGiangVien_ThongBao`) REFERENCES `giangvien` (`IDGiangVien`);

--
-- Các ràng buộc cho bảng `tiendo`
--
ALTER TABLE `tiendo`
  ADD CONSTRAINT `tiendo_ibfk_1` FOREIGN KEY (`IDDeTai_TienDo`) REFERENCES `detai` (`IDDeTai`),
  ADD CONSTRAINT `tiendo_ibfk_2` FOREIGN KEY (`IDSinhVien_TienDo`) REFERENCES `sinhvien` (`IDSinhVien`);

--
-- Các ràng buộc cho bảng `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`IDGiangVien`) REFERENCES `giangvien` (`IDGiangVien`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`IDSinhVien`) REFERENCES `sinhvien` (`IDSinhVien`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
